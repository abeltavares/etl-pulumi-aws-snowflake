from lambda_handler_factory import LambdaHandlerFactory
from lambda_strategy import Context, GlueJobStrategy, SnowflakeLoadStrategy


def lambda_handler(event, context):
    # Determine the job type based on event information or parameters
    job_type = event.get("job_type", "default")  # Default if not specified

    # Get the appropriate handler using the Factory pattern
    handler = LambdaHandlerFactory.get_handler(job_type)

    # Setup strategy context based on the determined job type
    if job_type == "glue_trigger":
        strategy_context = Context(GlueJobStrategy())
    elif job_type == "snowflake_load":
        strategy_context = Context(SnowflakeLoadStrategy())
    else:
        # Default strategy or error handling
        return {"statusCode": 400, "body": "Unsupported job type specified"}

    # Execute the strategy to process the data
    try:
        # Here, 'data' needs to be defined or extracted from the event
        data = event.get("data")  # Example placeholder
        strategy_context.execute_strategy(data)

        # Invoke the handler function and return its response
        return handler(event, context)
    except Exception as e:
        print(f"Error processing event with {job_type}: {str(e)}")
        return {"statusCode": 500, "body": f"Error processing event: {str(e)}"}
