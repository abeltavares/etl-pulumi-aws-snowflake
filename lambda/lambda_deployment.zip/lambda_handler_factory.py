from lambda_trigger_glue import glue_trigger_handler
from lambda_load_snowflake import snowflake_load_handler


class LambdaHandlerFactory:
    @staticmethod
    def get_handler(job_type):
        if job_type == "glue_trigger":
            return glue_trigger_handler
        elif job_type == "snowflake_load":
            return snowflake_load_handler
        else:
            raise ValueError("Unsupported job type")
