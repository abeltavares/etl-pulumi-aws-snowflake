# lambda_load_snowflake.py
import snowflake.connector
import os


def handler(event, context):
    # Snowflake connection details
    conn = snowflake.connector.connect(
        user=os.getenv("SNOWFLAKE_USER"),
        password=os.getenv("SNOWFLAKE_PASSWORD"),
        account=os.getenv("SNOWFLAKE_ACCOUNT"),
        warehouse=os.getenv("SNOWFLAKE_WAREHOUSE"),
        database=os.getenv("SNOWFLAKE_DATABASE"),
        schema=os.getenv("SNOWFLAKE_SCHEMA"),
    )

    # Cursor to execute SQL commands
    cursor = conn.cursor()

    try:
        # Iterate over records and load each relevant file into Snowflake
        for record in event["Records"]:
            s3_path = (
                f"s3://{record['s3']['bucket']['name']}/{record['s3']['object']['key']}"
            )
            copy_command = f"COPY INTO {os.getenv('SNOWFLAKE_TABLE')} FROM '{s3_path}' FILE_FORMAT = (TYPE = 'JSON', COMPRESSION = 'AUTO')"
            cursor.execute(copy_command)
            print(
                f"Data loaded from {s3_path} to Snowflake table {os.getenv('SNOWFLAKE_TABLE')}"
            )

        return {"statusCode": 200, "body": "Data loaded into Snowflake successfully"}
    except Exception as e:
        print(f"Error loading data into Snowflake: {str(e)}")
        return {
            "statusCode": 500,
            "body": f"Error loading data into Snowflake: {str(e)}",
        }
    finally:
        cursor.close()
        conn.close()
