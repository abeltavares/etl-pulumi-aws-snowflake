class ProcessingStrategy:
    def process(self, data):
        raise NotImplementedError("Each strategy must implement the process method.")


class GlueJobStrategy(ProcessingStrategy):
    def process(self, data):
        print("Processing data with AWS Glue")
        # Implementation for triggering a Glue job


class SnowflakeLoadStrategy(ProcessingStrategy):
    def process(self, data):
        print("Loading data into Snowflake")
        # Implementation for loading data into Snowflake


class Context:
    def __init__(self, strategy):
        self._strategy = strategy

    def set_strategy(self, strategy):
        self._strategy = strategy

    def execute_strategy(self, data):
        self._strategy.process(data)
