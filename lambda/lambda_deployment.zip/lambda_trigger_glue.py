import boto3
import os
import time


def handler(event, context):
    # Create a Glue client
    glue_client = boto3.client("glue")

    # Get the name of the Glue Crawler and Glue job from environment variables
    glue_crawler_name = os.getenv("GLUE_CRAWLER_NAME")
    glue_job_name = os.getenv("GLUE_JOB_NAME")

    try:
        # Start the Glue Crawler
        glue_client.start_crawler(Name=glue_crawler_name)

        # Wait for the Glue Crawler to finish running
        while True:
            crawler_metadata = glue_client.get_crawler(Name=glue_crawler_name)
            if crawler_metadata["Crawler"]["State"] != "RUNNING":
                break
            time.sleep(60)  # Wait for 60 seconds before checking the Crawler status again

        # Start the Glue job
        response = glue_client.start_job_run(JobName=glue_job_name)
        print(f"Glue job started successfully: {response['JobRunId']}")
        return {
            "statusCode": 200,
            "body": f"Glue job {glue_job_name} started successfully with JobRunId {response['JobRunId']}",
        }
    except Exception as e:
        print(f"Error starting Glue job: {str(e)}")
        return {
            "statusCode": 500,
            "body": f"Error starting Glue job {glue_job_name}: {str(e)}",
        }
